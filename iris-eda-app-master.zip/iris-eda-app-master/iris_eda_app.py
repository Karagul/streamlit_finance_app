import streamlit as st 

def main():
	""" A simple Iris EDA App """

	st.title("Iris EDA App with streamlit")
	st.subheader("Streamlit is Cool")

if __name__ == '__main__':
	main()