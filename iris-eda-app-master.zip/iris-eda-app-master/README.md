# iris-eda-app
Simple Iris EDA app with streamlit

# Required Files
1 setup.sh
2 Procfile
3 requirements.txt